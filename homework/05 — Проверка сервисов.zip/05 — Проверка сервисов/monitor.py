import json
import time
import requests

while True:
    with open("services.json", "r", encoding="utf-8") as f:
        services = json.load(f)["services"]

    for s in services:
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        try:
            r = requests.get(s["url"], timeout=s["timeout_seconds"])
            if r.status_code == 200:
                msg = f"[{now}] {s['name']} -> OK (200)"
            else:
                msg = f"[{now}] {s['name']} -> ОШИБКА HTTP {r.status_code}"

        except requests.exceptions.ReadTimeout:
            msg = f"[{now}] {s['name']} -> ТАЙМ-АУТ"

        except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError):

            msg = f"[{now}] {s['name']} -> ПОРТ НЕДОСТУПЕН"

        print(msg)
        with open("log.txt", "a", encoding="utf-8") as log_file:
            log_file.write(msg + "\n")

    print("-" * 30)
    time.sleep(5)
